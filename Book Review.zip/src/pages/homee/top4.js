import React from 'react';
function Top4() {
    return( 
     <div style={{backgroundColor:"#EF5453",height:"200px", display: 'flex', flexDirection: 'column', justifyContent: 'center'}}>
        <h1 style={{paddingRight: "15%",paddingLeft:"15%",textAlign:"center", color:"white", alignSelf: 'center'}}>"GOOD FRIENDS ,GOOD BOOKS AND SLEEPY CONSCIENCE :THIS IS THE IDEAL LIFE"</h1>
        <h3 className='down4' style={{paddingRight: "15%",paddingLeft:"15%",textAlign:"center", color:"white", alignSelf: 'center'}}><b>Mark Twain</b></h3>
    </div>

    
 )   
}
export default Top4;        
import React from 'react'
import Navbar from "../component/navbar";
import Footer from "../component/footer";


function Book() {
    return (
        <div className="bg-light">
          <Navbar />
          <h1>Book</h1>
          <Footer/>

        </div>
      );
    
}
export default Book;